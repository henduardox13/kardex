package com.example.demo.controller;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.ProductsMovement;
import com.example.demo.entity.User;
import com.example.demo.service.ProductsMovementInterface;

import antlr.collections.List;

@RestController
@RequestMapping("/api/productsmovement")
public class ProductsMovementController {
	
	@Autowired
	private ProductsMovementInterface productsMovementInterface;
	
				// Create 
				@PostMapping
				public ResponseEntity<?> create(@RequestBody ProductsMovement productsMovement){
					return ResponseEntity.status(HttpStatus.CREATED).body(productsMovementInterface.save(productsMovement));
				}
				
				// Read 
				@GetMapping("/{id}")
				public ResponseEntity<?> read(@PathVariable Long id){
					Optional<ProductsMovement> oInventoryMovement = productsMovementInterface.findById(id);
					if(!oInventoryMovement.isPresent()) {
						return ResponseEntity.notFound().build();
					}
					return ResponseEntity.ok(oInventoryMovement);
				}
				
				
				
				//Read all
				@GetMapping
				public List<ProductsMovement> readAll(){
					List<ProductsMovement> productsMovement = StreamSupport
							.stream(productsMovementInterface.findAll().spliterator(), false)
							.collect(Collectors.toList());
					return productsMovement;
					
				}
	
	

}

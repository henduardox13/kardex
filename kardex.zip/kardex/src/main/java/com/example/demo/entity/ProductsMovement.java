package com.example.demo.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "products_movements")
public class ProductsMovement implements Serializable {
	
	
	private static final long serialVersionUID = 4301267636368585970L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	private Long  id_movements;
	
	private Long  id_products;
	
	private Long 	amount;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getId_movements() {
		return id_movements;
	}

	public void setId_movements(Long id_movements) {
		this.id_movements = id_movements;
	}

	public Long getId_products() {
		return id_products;
	}

	public void setId_products(Long id_products) {
		this.id_products = id_products;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}
	
	
	
	


}

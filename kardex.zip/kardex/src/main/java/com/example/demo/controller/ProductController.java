package com.example.demo.controller;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Product;
import com.example.demo.service.ProductInterface;

import antlr.collections.List;

@RestController
@RequestMapping("/api/product")
public class ProductController {
	
	@Autowired
	private ProductInterface productInterface;
	
	// Create 
		@PostMapping
		public ResponseEntity<?> create(@RequestBody Product product){
			return ResponseEntity.status(HttpStatus.CREATED).body(productInterface.save(product));
		}
		
		// Read 
		@GetMapping("/{id}")
		public ResponseEntity<?> read(@PathVariable Long id){
			Optional<Product> oProduct = productInterface.findById(id);
			if(!oProduct.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			return ResponseEntity.ok(oProduct);
		}
		
		//Update
		@PutMapping("/{id}")
		public ResponseEntity<?> update(@RequestBody Product product ,@PathVariable Long id ){
			Optional<Product> theproduct = productInterface.findById(id);
			
			if(!theproduct.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			theproduct.get().setAmount(product.getAmount());
			theproduct.get().setName(product.getName());
			theproduct.get().setDescription(product.getDescription());
			
			
			
			return ResponseEntity.status(HttpStatus.CREATED).body(productInterface.save(theproduct.get()));
			
			
		}
		
		//Delete
		@DeleteMapping("/{id}")
		public ResponseEntity<?> delete(@PathVariable Long id ){
			Optional<Product> product = productInterface.findById(id);
			
			if(!product.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			
			productInterface.deleteById(id);
			return ResponseEntity.ok().build();
			
		}
		
		//Read all
		@GetMapping
		public List<Product> readAll(){
			List<Product> product = StreamSupport
					.stream(productInterface.findAll().spliterator(), false)
					.collect(Collectors.toList());
			return product;
			
		}
		

}

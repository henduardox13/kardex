package com.example.demo.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.example.demo.entity.InventoryMovement;

public interface InventoryMovementInterface {
	
	public Iterable<InventoryMovement> findAll();
	
	public Page<InventoryMovement> findAll(Pageable pageable);
	
	public Optional<InventoryMovement> findById(Long id );
	
	public InventoryMovement save(InventoryMovement inventorymovement);
	
	public void deleteById(Long id);
	

}

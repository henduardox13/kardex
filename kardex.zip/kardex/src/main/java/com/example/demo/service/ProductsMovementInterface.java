package com.example.demo.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.example.demo.entity.ProductsMovement;

public interface ProductsMovementInterface {
	
	public Iterable<ProductsMovement> findAll();
	
	public Page<ProductsMovement> findAll(Pageable pageable);
	
	public Optional<ProductsMovement> findById(Long id );
	
	public ProductsMovement save(ProductsMovement productsmovement);
	
	public void deleteById(Long id);

}

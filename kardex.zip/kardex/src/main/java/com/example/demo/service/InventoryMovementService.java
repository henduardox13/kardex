package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.InventoryMovement;
import com.example.demo.repository.InventoryMovementRepository;

@Service
public class InventoryMovementService implements InventoryMovementInterface{
	
	@Autowired 
	private InventoryMovementRepository inventoryMovementRepository;

	@Override
	@Transactional(readOnly = true)
	public Iterable<InventoryMovement> findAll() {
		
		return inventoryMovementRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<InventoryMovement> findAll(Pageable pageable) {
		
		return inventoryMovementRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<InventoryMovement> findById(Long id) {
		
		return inventoryMovementRepository.findById(id);
	}

	@Override
	@Transactional
	public InventoryMovement save(InventoryMovement inventorymovement) {
		
		return inventoryMovementRepository.save(inventorymovement);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		inventoryMovementRepository.deleteById(id);
		
	}

}

package com.example.demo.controller;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.UserInterface;

import antlr.collections.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
	
	@Autowired
	private UserInterface userInterface;
	
	
	// Create 
	@PostMapping
	public ResponseEntity<?> create(@RequestBody User user){
		return ResponseEntity.status(HttpStatus.CREATED).body(userInterface.save(user));
	}
	
	// Read 
	@GetMapping("/{id}")
	public ResponseEntity<?> read(@PathVariable Long id){
		Optional<User> oUser = userInterface.findById(id);
		if(!oUser.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(oUser);
	}
	
	//Update
	@PutMapping("/{id}")
	public ResponseEntity<?> update(@RequestBody User user ,@PathVariable Long id ){
		Optional<User> theuser = userInterface.findById(id);
		
		if(!theuser.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		
		theuser.get().setName_surname(user.getName_surname());
		theuser.get().setUser(user.getUser());
		theuser.get().setPassword(user.getPassword());
		
		return ResponseEntity.status(HttpStatus.CREATED).body(userInterface.save(theuser.get()));
		
		
	}
	
	//Delete
	@DeleteMapping("/{id}")
	public ResponseEntity<?> delete(@PathVariable Long id ){
		Optional<User> user = userInterface.findById(id);
		
		if(!user.isPresent()) {
			return ResponseEntity.notFound().build();
		}
		
		userInterface.deleteById(id);
		return ResponseEntity.ok().build();
		
	}
	
	//Read all
	@GetMapping
	public List<User> readAll(){
		List<User> users = StreamSupport
				.stream(userInterface.findAll().spliterator(), false)
				.collect(Collectors.toList());
		return users;
		
	}
	
	
	
	
	
	
	
	
	

}

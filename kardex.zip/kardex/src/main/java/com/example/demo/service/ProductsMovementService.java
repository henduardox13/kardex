package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.ProductsMovement;
import com.example.demo.repository.ProductsMovementRepository;

@Service
public class ProductsMovementService implements ProductsMovementInterface {
	
	@Autowired 
	private ProductsMovementRepository productsMovementRepository ;

	@Override
	@Transactional(readOnly = true)
	public Iterable<ProductsMovement> findAll() {
		
		return productsMovementRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Page<ProductsMovement> findAll(Pageable pageable) {
		
		return productsMovementRepository.findAll(pageable);
	}

	@Override
	@Transactional(readOnly = true)
	public Optional<ProductsMovement> findById(Long id) {
		
		return productsMovementRepository.findById(id);
	}

	@Override
	@Transactional
	public ProductsMovement save(ProductsMovement productsmovement) {
	
		return productsMovementRepository.save(productsmovement);
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		productsMovementRepository.deleteById(id);
		
	}

}
